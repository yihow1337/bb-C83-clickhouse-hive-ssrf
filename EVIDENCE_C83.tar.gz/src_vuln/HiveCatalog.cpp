#include <Databases/DataLake/HiveCatalog.h>
#include <algorithm>
#include <cctype>
#if USE_AVRO && USE_HIVE
#include <optional>
#include <Common/Exception.h>
#include <Core/Names.h>
#include <Databases/DataLake/ICatalog.h>

#include <IO/S3/Client.h>
#include <IO/S3/Credentials.h>
#include <IO/S3Settings.h>
#include <Storages/ObjectStorage/DataLakes/Iceberg/SchemaProcessor.h>
#include <Common/ProxyConfigurationResolverProvider.h>
#include <Databases/DataLake/Common.h>
#include <Common/FailPoint.h>

namespace DB::ErrorCodes
{
    extern const int DATALAKE_DATABASE_ERROR;
    extern const int FAULT_INJECTED;
    extern const int NO_HIVEMETASTORE;
}

namespace DB::FailPoints
{
    extern const char check_database_datalake_negative[];
}

namespace DataLake
{

namespace
{

std::pair<String, Int32> parseHostPort(const String & url)
{
    auto protocol_sep = url.find("://");
    if (protocol_sep == String::npos)
        throw DB::Exception(DB::ErrorCodes::DATALAKE_DATABASE_ERROR, "Invalid URL format: missing protocol separator '://'");

    size_t start = protocol_sep + 3;

    auto colon_pos = url.find(':', start);
    if (colon_pos == String::npos)
        throw DB::Exception(DB::ErrorCodes::DATALAKE_DATABASE_ERROR, "Invalid URL format: missing port number");

    auto slash_pos = url.find('/', start);

    String host = url.substr(start, colon_pos - start);

    size_t port_end = (slash_pos != String::npos) ? slash_pos : url.size();
    String port_str = url.substr(colon_pos + 1, port_end - colon_pos - 1);

    if (port_str.empty() || !std::all_of(port_str.begin(), port_str.end(), ::isdigit))
        throw DB::Exception(DB::ErrorCodes::DATALAKE_DATABASE_ERROR, "Invalid port number: '{}'", port_str);

    try
    {
        Int32 port = std::stoi(port_str);
        if (port <= 0 || port > 65535)
            throw DB::Exception(DB::ErrorCodes::DATALAKE_DATABASE_ERROR, "Port number out of valid range (1-65535): {}", port);
        return {host, port};
    }
    catch (const std::out_of_range&)
    {
        throw DB::Exception(DB::ErrorCodes::DATALAKE_DATABASE_ERROR, "Invalid port number format: {}", port_str);
    }
    catch (const std::invalid_argument&)
    {
        throw DB::Exception(DB::ErrorCodes::DATALAKE_DATABASE_ERROR, "Invalid port number: '{}'", port_str);
    }
}

}

HiveCatalog::HiveCatalog(const std::string & warehouse_, const std::string & base_url_, DB::ContextPtr)
    : ICatalog(warehouse_)
    , base_url(base_url_)
{
    std::lock_guard lock(client_mutex);
    reconnectUnlocked();
}

void HiveCatalog::reconnectUnlocked() const TSA_REQUIRES(client_mutex)
{
    if (transport && transport->isOpen())
    {
        try
        {
            transport->close();
        }
        catch (const std::exception & ex)
        {
            LOG_TRACE(&Poco::Logger::get("HiveCatalog"), "Error closing transport: {}", ex.what());
        }
    }

    auto [host, port] = parseHostPort(base_url);

    socket = std::make_shared<apache::thrift::transport::TSocket>(host, port);
    transport = std::make_shared<apache::thrift::transport::TBufferedTransport>(socket);
    protocol = std::make_shared<apache::thrift::protocol::TBinaryProtocol>(transport);
    client = std::make_unique<Apache::Hadoop::Hive::ThriftHiveMetastoreClient>(protocol);

    transport->open();
}

template <typename Func>
void HiveCatalog::executeWithRetry(Func && func) const
{
    constexpr int max_retries = 3;
    String last_err_msg;

    for (int i = 0; i < max_retries; ++i)
    {
        std::unique_lock lock(client_mutex);

        try
        {
            func();
            return;
        }
        catch (apache::thrift::transport::TTransportException & e)
        {
            last_err_msg = e.what();

            try
            {
                reconnectUnlocked();
            }
            catch (const std::exception & ex)
            {
                LOG_TRACE(
                    &Poco::Logger::get("HiveCatalog"), "Reconnect failed in iteration {}/{} with error: {}", i, max_retries, ex.what());
            }
        }
    }

    throw DB::Exception(
        DB::ErrorCodes::NO_HIVEMETASTORE, "Hive Metastore connection failed after {} attempts. Last error: {}", max_retries, last_err_msg);
}

bool HiveCatalog::empty() const
{
    fiu_do_on(DB::FailPoints::check_database_datalake_negative,
    {
        throw DB::Exception(DB::ErrorCodes::FAULT_INJECTED, "Injecting fault when checking database");
    });

    std::vector<std::string> result;

    executeWithRetry([&]() TSA_NO_THREAD_SAFETY_ANALYSIS { client->get_all_databases(result); });
    return result.empty();
}

CatalogTables HiveCatalog::getTables() const
{
    CatalogTables result;
    DB::Names databases;

    executeWithRetry([&]() TSA_NO_THREAD_SAFETY_ANALYSIS { client->get_all_databases(databases); });

    for (const auto & db : databases)
    {
        DB::Names current_tables;
        executeWithRetry([&]() TSA_NO_THREAD_SAFETY_ANALYSIS { client->get_all_tables(current_tables, db); });
        /// A Hive catalog used with the Iceberg engine lists only Iceberg tables, so they are readable.
        for (const auto & table : current_tables)
            result.push_back(CatalogTable{.name = db + "." + table});
    }
    return result;
}

DataLake::ICatalog::Namespaces HiveCatalog::getNamespaces() const
{
    /// HMS databases are flat — they cannot contain nested namespaces.
    DB::Names databases;
    executeWithRetry([&]() TSA_NO_THREAD_SAFETY_ANALYSIS { client->get_all_databases(databases); });
    return databases;
}

CatalogTables HiveCatalog::listTablesInNamespaceDirect(const std::string & namespace_name) const
{
    DB::Names current_tables;
    /// Retry transient `TTransportException` (same wrapper as `getTables`) rather
    /// than letting it bubble up and become an empty table list.
    executeWithRetry([&]() TSA_NO_THREAD_SAFETY_ANALYSIS { client->get_all_tables(current_tables, namespace_name); });
    /// A Hive catalog used with the Iceberg engine lists only Iceberg tables, so they are readable.
    CatalogTables result;
    result.reserve(current_tables.size());
    for (const auto & table : current_tables)
        result.push_back(CatalogTable{.name = namespace_name + "." + table});
    return result;
}

bool HiveCatalog::existsTable(const std::string & namespace_name, const std::string & table_name) const
{
    Apache::Hadoop::Hive::Table table;

    executeWithRetry([&]() TSA_NO_THREAD_SAFETY_ANALYSIS { client->get_table(table, namespace_name, table_name); });

    if (table.tableName.empty())
        return false;

    return true;
}

void HiveCatalog::getTableMetadata(const std::string & namespace_name, const std::string & table_name, TableMetadata & result) const
{
    if (!tryGetTableMetadata(namespace_name, table_name, result))
        throw DB::Exception(DB::ErrorCodes::DATALAKE_DATABASE_ERROR, "No response from iceberg catalog");
}

bool HiveCatalog::tryGetTableMetadata(const std::string & namespace_name, const std::string & table_name, TableMetadata & result) const
{
    Apache::Hadoop::Hive::Table table;

    executeWithRetry([&]() TSA_NO_THREAD_SAFETY_ANALYSIS { client->get_table(table, namespace_name, table_name); });

    if (table.tableName.empty())
        return false;

    if (result.requiresLocation())
    {
        if (table.sd.location.empty())
            result.setTableIsNotReadable(fmt::format("Cannot read table {}, because no 'location' in response", table_name));
        else
        {
            result.setLocation(table.sd.location);
        }
    }

    if (result.requiresSchema())
    {
        DB::NamesAndTypesList schema;
        auto columns = table.sd.cols;
        for (const auto & column : columns)
        {
            schema.push_back({column.name, getType(column.type, true)});
        }
        result.setSchema(schema);
    }

    if (result.requiresDataLakeSpecificProperties())
    {
        if (auto it = table.parameters.find("metadata_location"); it != table.parameters.end())
            result.setDataLakeSpecificProperties(DataLakeSpecificProperties{.iceberg_metadata_file_location = it->second});
    }

    return true;
}

std::optional<StorageType> HiveCatalog::getStorageType() const
{
    return std::nullopt;
}

}
#endif
